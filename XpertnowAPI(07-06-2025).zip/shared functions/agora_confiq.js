const agora = {
    appID : "6229272645e343d1a3c2830bd74e1907",
    appCertificate : "37c0b35e13464051a66187081391a9fa",
    customerID : "a351e0bc35b44588b53090bd8dc5b3ff", // Replace with your Agora Customer ID
    customerSecret : "0d8f2b92f979428aae705f2d7c149270", // Replace with your Agora Customer Secret
    AGORA_APP_ID : "6229272645e343d1a3c2830bd74e1907",
    AGORA_APP_CERTIFICATE : "37c0b35e13464051a66187081391a9fa",
    CUSTOMER_ID : "a351e0bc35b44588b53090bd8dc5b3ff", // Replace with actual Customer ID
    CUSTOMER_SECRET : "0d8f2b92f979428aae705f2d7c149270", // Replace with actual Customer Secret
    REGION : 14, // AWS S3 region
    BUCKET_NAME : "xpertnowbucket", // Your S3 bucket
    accessKey: "AKIAUGO4KNQULGJQFZIA",
    secretKey: "uED2kfGmnJFGL/86NjfcBcISMVr8ayQ36QM3/dV5",
};
module.exports = agora; 
